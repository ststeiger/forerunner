﻿
using System.Reflection;
 
[assembly:AssemblyFileVersion("0.9.0.427")]
[assembly: AssemblyCompany("Forerunner Software")]
[assembly: AssemblyProduct("Mobilizer")]
[assembly: AssemblyCopyright("Copyright © Forerunner Software 2013")]

